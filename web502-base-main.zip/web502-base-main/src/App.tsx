import './App.css';

const App = () => {
	return (
		<div>
      <h1>Chúc các bạn làm bài tốt!</h1>
		</div>
	);
};

export default App;
