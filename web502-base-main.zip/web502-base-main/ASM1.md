- 50 phút làm bài.
- Không sử dụng công cụ tích hợp AI trong quá trình làm bài.
- Không tắt vscode trong quá trình làm bài.

## 1. Create base với react-typescript: (1đ)

- Tự tạo dự án với vitejs, react, typescript, swc.
- Cài đặt và sử dụng json-server với data cho sẵn trong db.json

## 2. Xây dựng các chức năng sau: (6đ)

- Header hiển thị bộ định tuyến. (1đ)
- Trang chủ: Hiển thị danh sách sản phẩm bao gồm: tên, ảnh, giá mô tả. (2đ)
- Trang chi tiết: Khi ấn vào tên hoặc ảnh sản phẩm thì hiển thị trang chi tiết sản phẩm (đầy đủ các thuộc tính trong database). (1đ)
- Trang About: Có tên sinh viên, mã sinh viên. (1đ)
- Nếu vào một path không tồn tại thì hiển thị trang Notfound. (1đ)

## 3. Giao diện (1đ)

## 4. Khai báo type cho dữ liệu (2đ)

- Khai báo type cho dữ liệu sản phẩm. (1đ)
- Khai báo kiểu dữ liệu cho các props. (0.5đ)
- Khai báo kiểu dữ liệu cho các hook được sử dụng (0.5đ)